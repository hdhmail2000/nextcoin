﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `e_admin`;
CREATE TABLE `e_admin` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `realname` varchar(50) DEFAULT NULL COMMENT '管理员姓名',
  `usermenu` text COMMENT '自定义面板菜单，序列化数组格式',
  `color` text NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=9990 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理员表';

DROP TABLE IF EXISTS  `e_admin_menu`;
CREATE TABLE `e_admin_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL COMMENT '上级菜单id',
  `name` text NOT NULL COMMENT '菜单语言名称',
  `uri` varchar(255) DEFAULT NULL COMMENT 'uri字符串',
  `url` varchar(255) DEFAULT NULL COMMENT '外链地址',
  `mark` varchar(100) DEFAULT NULL COMMENT '菜单标识',
  `hidden` tinyint(1) unsigned DEFAULT NULL COMMENT '是否隐藏',
  `displayorder` tinyint(3) unsigned DEFAULT NULL COMMENT '排序值',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标标示',
  PRIMARY KEY (`id`),
  KEY `list` (`pid`),
  KEY `displayorder` (`displayorder`),
  KEY `mark` (`mark`),
  KEY `hidden` (`hidden`),
  KEY `uri` (`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='后台菜单表';

DROP TABLE IF EXISTS  `e_admin_login`;
CREATE TABLE `e_admin_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned DEFAULT NULL COMMENT '会员uid',
  `loginip` varchar(50) NOT NULL COMMENT '登录Ip',
  `logintime` int(10) unsigned NOT NULL COMMENT '登录时间',
  `useragent` varchar(255) NOT NULL COMMENT '客户端信息',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `loginip` (`loginip`),
  KEY `logintime` (`logintime`)
) ENGINE=InnoDB AUTO_INCREMENT=418 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='登录日志记录';

DROP TABLE IF EXISTS  `e_admin_notice`;
CREATE TABLE `e_admin_notice` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `type` varchar(20) NOT NULL COMMENT '提醒类型：系统、内容、会员、应用',
  `msg` text NOT NULL COMMENT '提醒内容说明',
  `uri` varchar(100) NOT NULL COMMENT '对应的URI',
  `to_rid` smallint(5) NOT NULL COMMENT '指定角色组',
  `to_uid` int(10) NOT NULL COMMENT '指定管理员',
  `status` tinyint(1) NOT NULL COMMENT '未处理0，1已查看，2处理中，3处理完成',
  `uid` int(10) NOT NULL COMMENT '处理人',
  `username` varchar(100) NOT NULL COMMENT '处理人',
  `updatetime` int(10) NOT NULL COMMENT '处理时间',
  `inputtime` int(10) NOT NULL COMMENT '提醒时间',
  PRIMARY KEY (`id`),
  KEY `uri` (`uri`),
  KEY `status` (`status`),
  KEY `to_uid` (`to_uid`),
  KEY `to_rid` (`to_rid`),
  KEY `updatetime` (`updatetime`),
  KEY `inputtime` (`inputtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='后台提醒表';

DROP TABLE IF EXISTS  `e_admin_role`;
CREATE TABLE `e_admin_role` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `site` text NOT NULL COMMENT '允许管理的站点，序列化数组格式',
  `name` text NOT NULL COMMENT '角色组语言名称',
  `system` text NOT NULL COMMENT '系统权限',
  `module` text NOT NULL COMMENT '模块权限',
  `application` text NOT NULL COMMENT '应用权限',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='后台角色权限表';

DROP TABLE IF EXISTS  `e_admin_verify`;
CREATE TABLE `e_admin_verify` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL COMMENT '名称',
  `verify` text NOT NULL COMMENT '审核部署',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='审核管理表';

DROP TABLE IF EXISTS  `e_attachment`;
CREATE TABLE `e_attachment` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `siteid` tinyint(3) unsigned NOT NULL COMMENT '站点id',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `tableid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '附件副表id',
  `download` mediumint(8) NOT NULL DEFAULT '0' COMMENT '下载次数',
  `filesize` int(10) unsigned NOT NULL COMMENT '文件大小',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filemd5` varchar(50) NOT NULL COMMENT '文件md5值',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `author` (`author`),
  KEY `relatedtid` (`related`),
  KEY `fileext` (`fileext`),
  KEY `filemd5` (`filemd5`),
  KEY `siteid` (`siteid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表';

DROP TABLE IF EXISTS  `e_application`;
CREATE TABLE `e_application` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `module` text COMMENT '模块划分',
  `dirname` varchar(50) NOT NULL COMMENT '目录名称',
  `setting` text COMMENT '配置信息',
  `disabled` tinyint(1) DEFAULT '0' COMMENT '是否禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dirname` (`dirname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='应用表';

DROP TABLE IF EXISTS  `e_attachment_0`;
CREATE TABLE `e_attachment_0` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表0';

DROP TABLE IF EXISTS  `e_attachment_1`;
CREATE TABLE `e_attachment_1` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表1';

DROP TABLE IF EXISTS  `e_attachment_3`;
CREATE TABLE `e_attachment_3` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表3';

DROP TABLE IF EXISTS  `e_attachment_2`;
CREATE TABLE `e_attachment_2` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表2';

DROP TABLE IF EXISTS  `e_attachment_4`;
CREATE TABLE `e_attachment_4` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表4';

DROP TABLE IF EXISTS  `e_attachment_5`;
CREATE TABLE `e_attachment_5` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表5';

DROP TABLE IF EXISTS  `e_attachment_6`;
CREATE TABLE `e_attachment_6` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表6';

DROP TABLE IF EXISTS  `e_attachment_7`;
CREATE TABLE `e_attachment_7` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表7';

DROP TABLE IF EXISTS  `e_attachment_9`;
CREATE TABLE `e_attachment_9` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表9';

DROP TABLE IF EXISTS  `e_attachment_8`;
CREATE TABLE `e_attachment_8` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `related` varchar(50) NOT NULL COMMENT '相关表标识',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表8';

DROP TABLE IF EXISTS  `e_attachment_unused`;
CREATE TABLE `e_attachment_unused` (
  `id` mediumint(8) unsigned NOT NULL COMMENT '附件id',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `author` varchar(50) NOT NULL COMMENT '会员',
  `siteid` tinyint(3) unsigned NOT NULL COMMENT '站点id',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '原文件名',
  `fileext` varchar(20) NOT NULL COMMENT '文件扩展名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `attachment` varchar(255) NOT NULL DEFAULT '' COMMENT '服务器路径',
  `remote` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '远程附件id',
  `attachinfo` text NOT NULL COMMENT '附件信息',
  `inputtime` int(10) unsigned NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `author` (`author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='未使用的附件表';

DROP TABLE IF EXISTS  `e_c2c_order`;
CREATE TABLE `e_c2c_order` (
  `id` bigint(18) NOT NULL AUTO_INCREMENT COMMENT 'oid',
  `sn` varchar(50) NOT NULL COMMENT '流水序列号',
  `pay_no` varchar(50) DEFAULT NULL COMMENT '付款参考号',
  `mid` varchar(50) NOT NULL COMMENT '模块名',
  `mid_id` int(10) DEFAULT NULL COMMENT '商品id',
  `buy_uid` mediumint(8) unsigned DEFAULT NULL COMMENT '购买者id',
  `buy_username` varchar(50) DEFAULT NULL COMMENT '购买者name',
  `buy_step` tinyint(1) NOT NULL COMMENT '购买步骤流程',
  `sell_uid` mediumint(8) unsigned DEFAULT NULL COMMENT '出售者id',
  `sell_username` varchar(50) DEFAULT NULL COMMENT '出售者name',
  `order_volume` decimal(20,6) DEFAULT '0.000000' COMMENT '数量',
  `order_time` int(11) DEFAULT NULL COMMENT '下单时间',
  `order_status` tinyint(1) unsigned DEFAULT NULL COMMENT '订单状态',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '单价',
  `order_price` decimal(10,2) DEFAULT NULL COMMENT '订单金额',
  `order_score` tinyint(11) DEFAULT NULL COMMENT '是否虚拟币支付',
  `pay_type` varchar(50) DEFAULT NULL COMMENT '付款方式',
  `pay_id` int(10) DEFAULT NULL COMMENT '付款id',
  `pay_status` tinyint(1) unsigned DEFAULT NULL COMMENT '付款状态',
  `pay_time` int(10) NOT NULL COMMENT '付款时间',
  `tableid` tinyint(3) unsigned DEFAULT '0' COMMENT '附表号',
  `flag` tinyint(1) DEFAULT NULL COMMENT '买入:0 卖出:1',
  `imgUrl` text COMMENT '申诉图片',
  `description` varchar(255) DEFAULT NULL COMMENT '申诉描述',
  PRIMARY KEY (`id`),
  KEY `sn` (`sn`),
  KEY `buy_uid` (`buy_uid`),
  KEY `buy_username` (`buy_username`),
  KEY `sell_uid` (`sell_uid`),
  KEY `sell_username` (`sell_username`),
  KEY `order_time` (`order_time`),
  KEY `order_status` (`order_status`),
  KEY `pay_id` (`pay_id`),
  KEY `pay_status` (`pay_status`),
  KEY `order_price` (`order_price`),
  KEY `mid` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='订单信息表';

DROP TABLE IF EXISTS  `e_coin_wallet`;
CREATE TABLE `e_coin_wallet` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(15) DEFAULT NULL,
  `symbol` int(11) DEFAULT NULL,
  `total` decimal(20,6) DEFAULT '0.000000' COMMENT '总数',
  `frozen` decimal(20,6) DEFAULT '0.000000' COMMENT '冻结数',
  PRIMARY KEY (`id`),
  KEY `fuservirtualwallet_fcoinid` (`symbol`) USING BTREE,
  KEY `fuservirtualwallet_fuid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `e_collection`;
CREATE TABLE `e_collection` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tradeId` int(11) unsigned DEFAULT NULL COMMENT '交易id',
  `fid` int(11) unsigned DEFAULT NULL COMMENT '用户id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='自选区（收藏表）';

DROP TABLE IF EXISTS  `e_comment`;
CREATE TABLE `e_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '名称',
  `value` text COMMENT '配置信息',
  `field` text COMMENT '自定义字段信息',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='评论配置表';

DROP TABLE IF EXISTS  `e_cron_queue`;
CREATE TABLE `e_cron_queue` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) unsigned NOT NULL COMMENT '类型',
  `value` text NOT NULL COMMENT '值',
  `status` tinyint(1) unsigned NOT NULL COMMENT '状态',
  `error` varchar(255) NOT NULL COMMENT '错误信息',
  `updatetime` int(10) unsigned NOT NULL COMMENT '执行时间',
  `inputtime` int(10) unsigned NOT NULL COMMENT '写入时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='任务队列表';

DROP TABLE IF EXISTS  `e_controller`;
CREATE TABLE `e_controller` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '名称',
  `app` varchar(100) NOT NULL COMMENT '网站,会员,后台',
  `type` tinyint(1) unsigned NOT NULL COMMENT '前台0会员1后台2',
  `cname` varchar(100) NOT NULL COMMENT '控制器名称',
  `file` varchar(100) NOT NULL COMMENT '文件路径',
  `url` varchar(255) NOT NULL COMMENT '访问地址',
  `meta_title` varchar(255) NOT NULL COMMENT '网页标题',
  `meta_keywords` varchar(255) NOT NULL COMMENT '网页关键字',
  `meta_description` varchar(255) NOT NULL COMMENT '网页描述',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  PRIMARY KEY (`id`),
  KEY `inputtime` (`inputtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自定义控制器表';

DROP TABLE IF EXISTS  `e_downservers`;
CREATE TABLE `e_downservers` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '服务器名',
  `server` varchar(255) NOT NULL COMMENT '服务器地址',
  `displayorder` tinyint(3) NOT NULL COMMENT '排序值',
  PRIMARY KEY (`id`),
  KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='下载镜像服务器';

DROP TABLE IF EXISTS  `e_field`;
CREATE TABLE `e_field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL COMMENT '字段别名语言',
  `fieldname` varchar(50) NOT NULL COMMENT '字段名称',
  `fieldtype` varchar(50) NOT NULL COMMENT '字段类型',
  `relatedid` smallint(5) unsigned NOT NULL COMMENT '相关id',
  `relatedname` varchar(50) NOT NULL COMMENT '相关表',
  `isedit` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可修改',
  `ismain` tinyint(1) unsigned NOT NULL COMMENT '是否主表',
  `issystem` tinyint(1) unsigned NOT NULL COMMENT '是否系统表',
  `ismember` tinyint(1) unsigned NOT NULL COMMENT '是否会员可见',
  `issearch` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可搜索',
  `disabled` tinyint(1) unsigned NOT NULL COMMENT '禁用？',
  `setting` text NOT NULL COMMENT '配置信息',
  `displayorder` tinyint(3) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `list` (`relatedid`,`disabled`,`issystem`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='字段表';

DROP TABLE IF EXISTS  `e_linkage`;
CREATE TABLE `e_linkage` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '菜单名称',
  `type` tinyint(1) unsigned NOT NULL,
  `code` char(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `module` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='联动菜单表';

DROP TABLE IF EXISTS  `e_linkage_data_1`;
CREATE TABLE `e_linkage_data_1` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `site` mediumint(5) unsigned NOT NULL COMMENT '站点id',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '上级id',
  `pids` varchar(255) DEFAULT NULL COMMENT '所有上级id',
  `name` varchar(30) NOT NULL COMMENT '栏目名称',
  `cname` varchar(30) NOT NULL COMMENT '别名',
  `child` tinyint(1) unsigned DEFAULT '0' COMMENT '是否有下级',
  `hidden` tinyint(1) unsigned DEFAULT '0' COMMENT '前端隐藏',
  `childids` text COMMENT '下级所有id',
  `displayorder` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cname` (`cname`),
  KEY `hidden` (`hidden`),
  KEY `list` (`site`,`displayorder`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='联动菜单数据表';

DROP TABLE IF EXISTS  `e_linkage_data_3`;
CREATE TABLE `e_linkage_data_3` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `site` smallint(5) unsigned NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '上级id',
  `pids` varchar(255) DEFAULT NULL COMMENT '所有上级id',
  `name` varchar(30) NOT NULL COMMENT '菜单名称',
  `cname` varchar(255) NOT NULL COMMENT '菜单别名',
  `child` tinyint(1) unsigned DEFAULT '0' COMMENT '是否有下级',
  `hidden` tinyint(1) unsigned DEFAULT '0' COMMENT '前端隐藏',
  `childids` text COMMENT '下级所有id',
  `displayorder` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cname` (`cname`),
  KEY `hidden` (`hidden`),
  KEY `list` (`site`,`displayorder`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='联动菜单数据表';

DROP TABLE IF EXISTS  `e_linkage_data_2`;
CREATE TABLE `e_linkage_data_2` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `site` smallint(5) unsigned NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '上级id',
  `pids` varchar(255) DEFAULT NULL COMMENT '所有上级id',
  `name` varchar(30) NOT NULL COMMENT '菜单名称',
  `cname` varchar(255) NOT NULL COMMENT '菜单别名',
  `child` tinyint(1) unsigned DEFAULT '0' COMMENT '是否有下级',
  `hidden` tinyint(1) unsigned DEFAULT '0' COMMENT '前端隐藏',
  `childids` text COMMENT '下级所有id',
  `displayorder` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cname` (`cname`),
  KEY `hidden` (`hidden`),
  KEY `list` (`site`,`displayorder`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='联动菜单数据表';

DROP TABLE IF EXISTS  `e_mail_queue`;
CREATE TABLE `e_mail_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL COMMENT '邮件地址',
  `subject` varchar(255) NOT NULL COMMENT '邮件标题',
  `message` text NOT NULL COMMENT '邮件内容',
  `status` tinyint(1) unsigned NOT NULL COMMENT '发送状态',
  `updatetime` int(10) unsigned NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `updatetime` (`updatetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='邮件队列表';

DROP TABLE IF EXISTS  `e_member`;
CREATE TABLE `e_member` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `email` char(40) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` char(32) NOT NULL DEFAULT '' COMMENT '加密密码',
  `salt` char(10) NOT NULL COMMENT '随机加密码',
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `phone` char(20) NOT NULL COMMENT '手机号码',
  `avatar` varchar(255) NOT NULL COMMENT '头像地址',
  `money` decimal(10,2) unsigned NOT NULL COMMENT 'RMB',
  `freeze` decimal(10,2) unsigned NOT NULL COMMENT '冻结RMB',
  `spend` decimal(10,2) unsigned NOT NULL COMMENT '消费RMB总额',
  `score` int(10) unsigned NOT NULL COMMENT '虚拟币',
  `experience` int(10) unsigned NOT NULL COMMENT '经验值',
  `adminid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '管理组id',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '用户组id',
  `levelid` smallint(5) unsigned NOT NULL COMMENT '会员级别',
  `overdue` int(10) unsigned NOT NULL COMMENT '到期时间',
  `regip` varchar(15) NOT NULL COMMENT '注册ip',
  `regtime` int(10) unsigned NOT NULL COMMENT '注册时间',
  `randcode` mediumint(6) unsigned NOT NULL COMMENT '随机验证码',
  `ismobile` tinyint(1) unsigned DEFAULT NULL COMMENT '手机认证标识',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `groupid` (`groupid`),
  KEY `adminid` (`adminid`),
  KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=31809 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员表';

DROP TABLE IF EXISTS  `e_member_address`;
CREATE TABLE `e_member_address` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL COMMENT '会员id',
  `city` mediumint(8) unsigned NOT NULL COMMENT '城市id',
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `phone` varchar(20) NOT NULL COMMENT '电话',
  `zipcode` varchar(10) NOT NULL COMMENT '邮编',
  `address` varchar(255) NOT NULL COMMENT '地址',
  `default` tinyint(1) unsigned NOT NULL COMMENT '是否默认',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员收货地址表';

DROP TABLE IF EXISTS  `e_mail_smtp`;
CREATE TABLE `e_mail_smtp` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `host` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `port` mediumint(8) unsigned NOT NULL,
  `displayorder` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='邮件账户表';

DROP TABLE IF EXISTS  `e_member_alipay`;
CREATE TABLE `e_member_alipay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT '0' COMMENT '录入者uid',
  `author` varchar(100) DEFAULT NULL COMMENT '录入者账号',
  `inputip` varchar(30) DEFAULT NULL COMMENT '录入者ip',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `username` varchar(255) DEFAULT NULL COMMENT '账号',
  `qrcode` varchar(255) DEFAULT NULL COMMENT '二维码',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `inputtime` (`inputtime`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='个人资料表单表';

DROP TABLE IF EXISTS  `e_member_bank`;
CREATE TABLE `e_member_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT '0' COMMENT '录入者uid',
  `author` varchar(100) DEFAULT NULL COMMENT '录入者账号',
  `inputip` varchar(30) DEFAULT NULL COMMENT '录入者ip',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `khh` varchar(255) DEFAULT NULL COMMENT '开户行',
  `khm` varchar(255) DEFAULT NULL COMMENT '开户名',
  `zhhm` varchar(500) DEFAULT NULL COMMENT '账户号码',
  `idCard` varchar(20) DEFAULT NULL COMMENT '身份证号',
  `phone` varchar(20) DEFAULT NULL COMMENT '预留电话',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `inputtime` (`inputtime`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='个人资料表单表';

DROP TABLE IF EXISTS  `e_member_data`;
CREATE TABLE `e_member_data` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `complete` tinyint(1) unsigned NOT NULL COMMENT '完善资料标识',
  `is_auth` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '实名认证标识',
  `chongzhi` int(10) DEFAULT '0',
  `tixian` int(10) DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=10042 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员表';

DROP TABLE IF EXISTS  `e_member_group`;
CREATE TABLE `e_member_group` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL COMMENT '会员组名称',
  `theme` varchar(255) NOT NULL COMMENT '风格目录',
  `template` varchar(50) NOT NULL COMMENT '模板目录',
  `price` decimal(10,2) NOT NULL COMMENT '售价',
  `unit` tinyint(1) unsigned NOT NULL COMMENT '价格单位:1虚拟卡，2金钱',
  `limit` tinyint(1) unsigned NOT NULL COMMENT '售价限制：1月，2半年，3年',
  `overdue` smallint(5) unsigned NOT NULL COMMENT '过期后变成的组',
  `allowregister` tinyint(1) unsigned NOT NULL COMMENT '是否允许会员注册',
  `allowapply` tinyint(1) unsigned NOT NULL COMMENT '是否允许会员申请',
  `allowapply_orther` tinyint(1) unsigned NOT NULL COMMENT '是否允许会员申请其他组',
  `allowspace` tinyint(1) unsigned NOT NULL COMMENT '是否允许会员空间',
  `allowfield` text NOT NULL COMMENT '可用字段，序列化数组格式',
  `spacefield` text NOT NULL COMMENT '空间字段，序列化数组格式',
  `spacedomain` tinyint(1) unsigned DEFAULT NULL COMMENT '是否启用空间域名',
  `spacetemplate` varchar(50) DEFAULT NULL COMMENT '空间默认模板',
  `displayorder` tinyint(3) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员组表';

DROP TABLE IF EXISTS  `e_member_level`;
CREATE TABLE `e_member_level` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` smallint(5) unsigned NOT NULL,
  `name` varchar(255) NOT NULL COMMENT '会员级别名称',
  `stars` tinyint(2) NOT NULL COMMENT '星星数量',
  `experience` int(10) unsigned NOT NULL COMMENT '经验值要求',
  `allowupgrade` tinyint(1) NOT NULL COMMENT '允许自动升级',
  PRIMARY KEY (`id`),
  KEY `experience` (`experience`),
  KEY `groupid` (`groupid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员级别表';

DROP TABLE IF EXISTS  `e_member_login`;
CREATE TABLE `e_member_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned DEFAULT NULL COMMENT '会员uid',
  `oauthid` varchar(30) NOT NULL COMMENT '快捷登录方式',
  `loginip` varchar(50) NOT NULL COMMENT '登录Ip',
  `logintime` int(10) unsigned NOT NULL COMMENT '登录时间',
  `useragent` varchar(255) NOT NULL COMMENT '客户端信息',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `loginip` (`loginip`),
  KEY `logintime` (`logintime`)
) ENGINE=InnoDB AUTO_INCREMENT=6357 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='登录日志记录';

DROP TABLE IF EXISTS  `e_member_menu`;
CREATE TABLE `e_member_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL COMMENT '上级菜单id',
  `name` text NOT NULL COMMENT '菜单名称',
  `uri` varchar(255) DEFAULT NULL COMMENT 'uri字符串',
  `url` varchar(255) DEFAULT NULL COMMENT 'url',
  `mark` varchar(50) DEFAULT NULL COMMENT '菜单标识',
  `hidden` tinyint(1) unsigned DEFAULT NULL COMMENT '是否隐藏',
  `target` tinyint(3) unsigned DEFAULT NULL COMMENT '新窗口',
  `displayorder` tinyint(3) unsigned DEFAULT NULL COMMENT '排序值',
  `icon` varchar(30) DEFAULT NULL COMMENT '图标',
  PRIMARY KEY (`id`),
  KEY `list` (`pid`),
  KEY `displayorder` (`displayorder`),
  KEY `mark` (`mark`),
  KEY `hidden` (`hidden`),
  KEY `uri` (`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员菜单表';

DROP TABLE IF EXISTS  `e_member_new_notice`;
CREATE TABLE `e_member_new_notice` (
  `uid` smallint(8) unsigned NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_0`;
CREATE TABLE `e_member_notice_0` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_1`;
CREATE TABLE `e_member_notice_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=294 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_3`;
CREATE TABLE `e_member_notice_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_2`;
CREATE TABLE `e_member_notice_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_4`;
CREATE TABLE `e_member_notice_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_5`;
CREATE TABLE `e_member_notice_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_6`;
CREATE TABLE `e_member_notice_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_7`;
CREATE TABLE `e_member_notice_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_8`;
CREATE TABLE `e_member_notice_8` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_notice_9`;
CREATE TABLE `e_member_notice_9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '类型',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '通知者uid',
  `isnew` tinyint(1) unsigned NOT NULL COMMENT '新提醒',
  `content` text NOT NULL COMMENT '通知内容',
  `inputtime` int(10) unsigned NOT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `isnew` (`isnew`),
  KEY `type` (`type`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=298 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员通知提醒表';

DROP TABLE IF EXISTS  `e_member_oauth`;
CREATE TABLE `e_member_oauth` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL COMMENT '会员uid',
  `oid` varchar(255) NOT NULL COMMENT 'OAuth返回id',
  `oauth` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `expire_at` int(10) unsigned NOT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员OAuth2授权表';

DROP TABLE IF EXISTS  `e_member_online`;
CREATE TABLE `e_member_online` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL COMMENT '在线时间',
  PRIMARY KEY (`uid`),
  KEY `time` (`time`)
) ENGINE=InnoDB AUTO_INCREMENT=31808 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员在线情况表';

DROP TABLE IF EXISTS  `e_member_paylog`;
CREATE TABLE `e_member_paylog` (
  `id` bigint(15) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL,
  `value` decimal(10,2) NOT NULL COMMENT '价格',
  `type` varchar(20) NOT NULL COMMENT '类型',
  `status` tinyint(1) unsigned NOT NULL COMMENT '状态',
  `order` varchar(255) DEFAULT NULL COMMENT '下单详情',
  `module` varchar(30) NOT NULL COMMENT '应用或模块目录',
  `note` varchar(255) NOT NULL COMMENT '备注',
  `inputtime` int(10) unsigned NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `order` (`order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='支付记录表';

DROP TABLE IF EXISTS  `e_member_scorelog`;
CREATE TABLE `e_member_scorelog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL COMMENT '积分0,虚拟币1',
  `value` int(10) NOT NULL COMMENT '分数变化值',
  `mark` varchar(50) NOT NULL COMMENT '标记',
  `note` varchar(255) NOT NULL COMMENT '备注',
  `inputtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `type` (`type`),
  KEY `mark` (`mark`),
  KEY `inputtime` (`inputtime`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='得分日志';

DROP TABLE IF EXISTS  `e_member_setting`;
CREATE TABLE `e_member_setting` (
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员属性参数表';

DROP TABLE IF EXISTS  `e_member_upgrade_log`;
CREATE TABLE `e_member_upgrade_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL COMMENT '用户id',
  `before_group` int(2) DEFAULT NULL COMMENT '升级前用户类型',
  `now_group` int(2) DEFAULT NULL COMMENT '升级后用户类型',
  `num` int(11) DEFAULT NULL COMMENT '发费数量',
  `inputtime` int(10) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='会员购买记录';

DROP TABLE IF EXISTS  `e_member_weixin`;
CREATE TABLE `e_member_weixin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT '0' COMMENT '录入者uid',
  `author` varchar(100) DEFAULT NULL COMMENT '录入者账号',
  `inputip` varchar(30) DEFAULT NULL COMMENT '录入者ip',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `username` varchar(255) DEFAULT NULL COMMENT '账号',
  `qrcode` varchar(255) DEFAULT NULL COMMENT '二维码',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `inputtime` (`inputtime`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='个人资料表单表';

DROP TABLE IF EXISTS  `e_module`;
CREATE TABLE `e_module` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `site` text COMMENT '站点划分',
  `dirname` varchar(50) NOT NULL COMMENT '目录名称',
  `share` tinyint(1) unsigned DEFAULT NULL COMMENT '是否共享模块',
  `extend` tinyint(1) unsigned DEFAULT NULL COMMENT '是否是扩展模块',
  `sitemap` tinyint(1) unsigned DEFAULT NULL COMMENT '是否生成地图',
  `setting` text COMMENT '配置信息',
  `disabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '禁用？',
  `displayorder` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dirname` (`dirname`),
  KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='模块表';

DROP TABLE IF EXISTS  `e_module_form`;
CREATE TABLE `e_module_form` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL COMMENT '模块目录',
  `name` varchar(50) NOT NULL COMMENT '表单名称',
  `table` varchar(50) NOT NULL COMMENT '表单表名称',
  `disabled` tinyint(1) unsigned NOT NULL COMMENT '是否禁用',
  `permission` text NOT NULL COMMENT '会员权限',
  `setting` text NOT NULL COMMENT '表单配置',
  PRIMARY KEY (`id`),
  KEY `table` (`table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='模块表单表';

DROP TABLE IF EXISTS  `e_site`;
CREATE TABLE `e_site` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '站点名称',
  `domain` varchar(50) NOT NULL COMMENT '站点域名',
  `setting` text NOT NULL COMMENT '站点配置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='站点表';

DROP TABLE IF EXISTS  `e_test`;
CREATE TABLE `e_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inputtime` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8 COMMENT='测试';

DROP TABLE IF EXISTS  `e_urlrule`;
CREATE TABLE `e_urlrule` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '规则类型',
  `name` varchar(50) NOT NULL COMMENT '规则名称',
  `value` text NOT NULL COMMENT '详细规则',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='URL规则表';

DROP TABLE IF EXISTS  `e_var`;
CREATE TABLE `e_var` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `name` varchar(100) NOT NULL COMMENT '变量描述名称',
  `cname` varchar(100) NOT NULL COMMENT '变量名称',
  `type` tinyint(2) NOT NULL COMMENT '变量类型',
  `value` text NOT NULL COMMENT '变量值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自定义变量表';

DROP TABLE IF EXISTS  `f_about`;
CREATE TABLE `f_about` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fabouttype` int(11) DEFAULT NULL,
  `fshortname` varchar(64) DEFAULT NULL,
  `fsort` int(11) DEFAULT NULL,
  `ftitle` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `fcontent` longtext CHARACTER SET utf8,
  `fshowid` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `ftype` (`fabouttype`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS  `f_about_type`;
CREATE TABLE `f_about_type` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fsort` int(11) DEFAULT NULL,
  `fstate` tinyint(1) DEFAULT NULL,
  `flanguageid` int(11) DEFAULT NULL,
  `ftitle` varchar(64) DEFAULT NULL,
  `fdescribe` varchar(255) DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `flanid` (`flanguageid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_activity_record`;
CREATE TABLE `f_activity_record` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  `fstate` int(11) DEFAULT '1',
  `fintrouid` int(11) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL,
  `frecharge` decimal(24,10) DEFAULT NULL,
  `fremark` varchar(255) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `f_activity_record_fuid` (`fuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_admin`;
CREATE TABLE `f_admin` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(32) DEFAULT NULL,
  `fpassword` varchar(32) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `froleid` int(11) DEFAULT NULL,
  `fgoogleauthenticator` varchar(128) DEFAULT NULL,
  `fgoogleurl` varchar(128) DEFAULT NULL,
  `fgooglebind` tinyint(1) DEFAULT '0',
  `fopengooglevalidate` tinyint(1) DEFAULT NULL,
  `fgooglevalidate` tinyint(1) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `frole_id` (`froleid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_agent`;
CREATE TABLE `f_agent` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL,
  `fphone` varchar(255) DEFAULT NULL,
  `fdomain` varchar(255) DEFAULT NULL,
  `fremark` varchar(255) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_api_auth`;
CREATE TABLE `f_api_auth` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fapikey` varchar(255) DEFAULT NULL,
  `fsecretkey` varchar(255) DEFAULT NULL,
  `fip` varchar(255) DEFAULT NULL,
  `fstatus` int(1) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `frate` decimal(24,10) unsigned DEFAULT NULL COMMENT '自定义的手续费',
  `fopenrate` tinyint(32) unsigned DEFAULT '0' COMMENT '是否开启自定义的手续费1开启0不开启，默认值是0',
  `fcount` int(32) unsigned DEFAULT '0' COMMENT 'api的访问次数',
  `frqip` varchar(32) DEFAULT '' COMMENT '允许请求的api',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_article`;
CREATE TABLE `f_article` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fistop` tinyint(1) DEFAULT '0',
  `farticletype` int(11) DEFAULT NULL,
  `flookcount` int(11) DEFAULT '0',
  `fcreateadmin` int(11) DEFAULT NULL,
  `fmodifyadmin` int(11) DEFAULT NULL,
  `ftitle` varchar(1024) DEFAULT NULL,
  `fkeyword` varchar(1024) DEFAULT NULL,
  `fdescription` varchar(1024) DEFAULT NULL,
  `fcontent` text,
  `fcreatedate` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `findeximg` varchar(512) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  `ftype` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `farticle_fid` (`fid`) USING BTREE,
  KEY `FK_Relationship_16` (`fcreateadmin`) USING BTREE,
  KEY `FK_Relationship_17` (`fmodifyadmin`) USING BTREE,
  KEY `FK_Relationship_18` (`farticletype`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_article_type`;
CREATE TABLE `f_article_type` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(128) DEFAULT NULL,
  `fkeywords` varchar(1024) DEFAULT NULL,
  `fdescription` varchar(1024) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `flanguageid` int(11) DEFAULT NULL,
  `ftypeid` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `flanguage_key` (`flanguageid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_beautiful`;
CREATE TABLE `f_beautiful` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fbid` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_coin_record`;
CREATE TABLE `f_coin_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `coin_id` int(11) DEFAULT NULL COMMENT '币种id',
  `value` decimal(24,10) DEFAULT NULL COMMENT '数量',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `inputtime` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11419 DEFAULT CHARSET=utf8 COMMENT='用户币加减记录';

DROP TABLE IF EXISTS  `f_cs_question`;
CREATE TABLE `f_cs_question` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fquestion` varchar(255) DEFAULT NULL,
  `foperation` varchar(255) DEFAULT NULL,
  `fdetail` mediumtext,
  `fresult` mediumtext,
  `fstatus` int(2) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_day_capital_coin`;
CREATE TABLE `f_day_capital_coin` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `frecharge` decimal(24,10) DEFAULT '0.0000000000',
  `fwithdraw` decimal(24,10) DEFAULT '0.0000000000',
  `fwithdrawwait` decimal(24,10) DEFAULT '0.0000000000',
  `ffees` decimal(24,10) DEFAULT '0.0000000000',
  `fnetfees` decimal(24,10) DEFAULT '0.0000000000',
  `fleverborrow` decimal(24,10) DEFAULT '0.0000000000',
  `fleverrepay` decimal(24,10) DEFAULT '0.0000000000',
  `fupdatetime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `fdaycoinid` (`fcoinid`) USING BTREE,
  KEY `fdaycointime` (`fcreatetime`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_day_capital_rmb`;
CREATE TABLE `f_day_capital_rmb` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fbank` decimal(24,10) DEFAULT '0.0000000000',
  `fzfb` decimal(24,10) DEFAULT '0.0000000000',
  `fwx` decimal(24,10) DEFAULT '0.0000000000',
  `fsuma` decimal(24,10) DEFAULT '0.0000000000',
  `fwithdraw` decimal(24,10) DEFAULT '0.0000000000',
  `fwithdrawother` decimal(24,10) DEFAULT NULL,
  `fwithdrawwait` decimal(24,10) DEFAULT '0.0000000000',
  `ffees` decimal(24,10) DEFAULT '0.0000000000',
  `fleverborrow` decimal(24,10) DEFAULT '0.0000000000',
  `fleverrepay` decimal(24,10) DEFAULT '0.0000000000',
  `fupdatetime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `fdayrmbtime` (`fcreatetime`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_day_operat`;
CREATE TABLE `f_day_operat` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `flogin` int(11) DEFAULT NULL,
  `fregister` int(11) DEFAULT NULL,
  `frealname` int(11) DEFAULT NULL,
  `fsms` int(11) DEFAULT NULL,
  `fmail` int(11) DEFAULT NULL,
  `fvip6` int(11) DEFAULT NULL,
  `fcode` int(11) DEFAULT NULL COMMENT '鍏呭?鐮',
  `fscore` int(11) DEFAULT NULL,
  `fsubmitquestion` int(11) DEFAULT NULL,
  `freplyquestion` int(11) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=265 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_day_sum`;
CREATE TABLE `f_day_sum` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `ftotle` decimal(24,10) DEFAULT '0.0000000000',
  `frozen` decimal(24,10) DEFAULT '0.0000000000',
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `fdaysumcoinid` (`fcoinid`) USING BTREE,
  KEY `fdaysumcointime` (`fcreatetime`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3054 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_day_trade_coin`;
CREATE TABLE `f_day_trade_coin` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `fbuy` decimal(24,10) DEFAULT '0.0000000000',
  `fsell` decimal(24,10) DEFAULT '0.0000000000',
  `fbuyfees` decimal(24,10) DEFAULT '0.0000000000',
  `fsellfees` decimal(24,10) DEFAULT '0.0000000000',
  `fbuyperson` int(11) DEFAULT NULL,
  `fsellperson` int(11) DEFAULT NULL,
  `fbuyentrust` int(11) DEFAULT NULL,
  `fsellentrust` int(11) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `fdaytradecoinid` (`fcoinid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1501 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_entrust`;
CREATE TABLE `f_entrust` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `ftradeid` int(11) unsigned DEFAULT NULL,
  `fbuycoinid` int(11) unsigned DEFAULT NULL,
  `fsellcoinid` int(11) unsigned DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fmatchtype` int(11) DEFAULT NULL,
  `flast` decimal(24,10) DEFAULT '0.0000000000',
  `flastamount` decimal(24,10) DEFAULT '0.0000000000',
  `flastcount` int(11) DEFAULT '0',
  `fprize` decimal(24,10) DEFAULT NULL,
  `fcount` decimal(24,10) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL,
  `fsuccessamount` decimal(24,10) DEFAULT NULL,
  `fleftcount` decimal(24,10) DEFAULT NULL,
  `ffees` decimal(24,10) DEFAULT NULL,
  `fleftfees` decimal(24,10) DEFAULT NULL,
  `fsource` int(11) DEFAULT NULL,
  `fhuobientrustid` bigint(11) DEFAULT NULL,
  `fhuobiaccountid` int(11) DEFAULT NULL,
  `flastupdattime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `fentrust_fuid` (`fuid`) USING BTREE,
  KEY `fentrust_fstatus` (`fstatus`) USING BTREE,
  KEY `fentrust_ftype` (`ftype`) USING BTREE,
  KEY `fentrust_fmatchtype` (`fmatchtype`) USING BTREE,
  KEY `fentrust_fsource` (`fsource`) USING BTREE,
  KEY `fentrust_fcreateTime` (`fcreatetime`) USING BTREE,
  KEY `fentrust_ftradeid` (`ftradeid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9360 DEFAULT CHARSET=utf8 COMMENT='委单';

DROP TABLE IF EXISTS  `f_entrust_history`;
CREATE TABLE `f_entrust_history` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fentrustid` int(11) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  `ftradeid` int(11) DEFAULT NULL,
  `fbuycoinid` int(11) DEFAULT NULL,
  `fsellcoinid` int(11) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fmatchtype` int(11) DEFAULT NULL,
  `flast` decimal(24,10) DEFAULT NULL,
  `fprize` decimal(24,10) DEFAULT NULL,
  `fcount` decimal(24,10) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL,
  `fsuccessamount` decimal(24,10) DEFAULT NULL,
  `fleftcount` decimal(24,10) DEFAULT NULL,
  `fleftfees` decimal(24,10) DEFAULT NULL,
  `ffees` decimal(24,10) DEFAULT NULL,
  `fsource` int(11) DEFAULT NULL,
  `fhuobientrustid` bigint(11) DEFAULT NULL,
  `fhuobiaccountid` int(11) DEFAULT NULL,
  `flastupdattime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `fentrust_fuid` (`fuid`) USING BTREE,
  KEY `fentrust_fstatus` (`fstatus`) USING BTREE,
  KEY `fentrust_ftype` (`ftype`) USING BTREE,
  KEY `fentrust_fmatchtype` (`fmatchtype`) USING BTREE,
  KEY `fentrust_fsource` (`fsource`) USING BTREE,
  KEY `fentrust_fcreateTime` (`fcreatetime`) USING BTREE,
  KEY `fentrust_fentrustid` (`fentrustid`) USING BTREE,
  KEY `fentrust_flastupdattime` (`flastupdattime`) USING BTREE,
  KEY `fentrust_ftradeid` (`ftradeid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9244 DEFAULT CHARSET=utf8 COMMENT='历史委单';

DROP TABLE IF EXISTS  `f_entrust_log`;
CREATE TABLE `f_entrust_log` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `ftradeid` int(11) DEFAULT NULL,
  `fentrusttype` int(11) DEFAULT NULL,
  `fentrustid` int(11) DEFAULT NULL,
  `fmatchid` int(11) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT '0.0000000000',
  `fprize` decimal(24,10) DEFAULT '0.0000000000',
  `fcount` decimal(24,10) DEFAULT '0.0000000000',
  `fisactive` tinyint(1) DEFAULT NULL,
  `flastupdattime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fremark` varchar(512) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `FK_Relationship_7` (`fentrustid`) USING BTREE,
  KEY `isactive_seq` (`fisactive`) USING BTREE,
  KEY `FVI_type_fk` (`ftradeid`) USING BTREE,
  KEY `fentrustlog_fcreatetime` (`fcreatetime`) USING BTREE,
  KEY `fentrustlog_fmatchid` (`fmatchid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11435 DEFAULT CHARSET=utf8 COMMENT='订单记录';

DROP TABLE IF EXISTS  `f_identity_info`;
CREATE TABLE `f_identity_info` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fusername` varchar(32) DEFAULT NULL COMMENT '鍚嶅瓧',
  `fidentityno` varchar(32) DEFAULT NULL COMMENT '韬?唤璇佸彿鐮',
  `fcreatetime` datetime DEFAULT NULL COMMENT '鍒涘缓鏃ユ湡',
  `fisok` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_friend_link`;
CREATE TABLE `f_friend_link` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(128) DEFAULT NULL,
  `fdescription` varchar(1024) DEFAULT NULL,
  `forder` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `furl` varchar(128) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_log_admin_action`;
CREATE TABLE `f_log_admin_action` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fadminid` int(11) NOT NULL,
  `fuid` int(11) DEFAULT NULL,
  `ftype` int(11) NOT NULL,
  `fdatatype` int(11) DEFAULT NULL,
  `fcapitaltype` int(11) DEFAULT NULL,
  `fdata` decimal(24,10) DEFAULT NULL,
  `fcontent` varchar(255) DEFAULT NULL,
  `fip` varchar(255) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=1286 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_log_console_virtual_recharge`;
CREATE TABLE `f_log_console_virtual_recharge` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `famount` decimal(25,10) DEFAULT NULL,
  `fcoinid` int(11) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fstatus` int(1) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  `fissendmsg` int(1) DEFAULT NULL,
  `fcreatorid` int(11) DEFAULT NULL,
  `finfo` varchar(512) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `fk_voperationLog_VCoinTypeId` (`fcoinid`) USING BTREE,
  KEY `fk_voperationLog_UserId` (`fuid`) USING BTREE,
  KEY `fk_voperationLog_CreatorId` (`fcreatorid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_log_modify_capital_operation`;
CREATE TABLE `f_log_modify_capital_operation` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `faccount` varchar(256) DEFAULT NULL,
  `fadminid` int(11) DEFAULT NULL,
  `fbank` varchar(256) DEFAULT NULL,
  `fpayee` varchar(256) DEFAULT NULL,
  `fphone` varchar(64) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL COMMENT '鏈?慨鏀圭殑閲戦?',
  `fmodifyamount` decimal(24,10) DEFAULT NULL COMMENT '淇?敼杩囧悗鐨勯噾棰',
  `fupdatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_log_user_action`;
CREATE TABLE `f_log_user_action` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) NOT NULL,
  `ftype` int(11) NOT NULL,
  `fdatatype` int(11) DEFAULT NULL,
  `fcapitaltype` int(11) DEFAULT NULL,
  `fdata` decimal(24,10) DEFAULT NULL,
  `ffees` decimal(24,10) DEFAULT NULL,
  `fcontent` varchar(255) DEFAULT NULL,
  `fip` varchar(255) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=219772 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_log_user_score`;
CREATE TABLE `f_log_user_score` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fscore` int(11) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fremark` varchar(255) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=36111 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_mining_register`;
CREATE TABLE `f_mining_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='创世挖矿期注册的会员';

DROP TABLE IF EXISTS  `f_pool`;
CREATE TABLE `f_pool` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `faddress` varchar(256) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `fvir_fk` (`fcoinid`) USING BTREE,
  KEY `status_fk` (`fstatus`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7724 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_period`;
CREATE TABLE `f_period` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `ftradeid` int(11) DEFAULT NULL,
  `fkai` decimal(24,10) DEFAULT NULL,
  `fgao` decimal(24,10) DEFAULT NULL,
  `fdi` decimal(24,10) DEFAULT NULL,
  `fshou` decimal(24,10) DEFAULT NULL,
  `fliang` decimal(24,10) DEFAULT NULL,
  `ftime` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `ftime_seq` (`ftime`) USING BTREE,
  KEY `fvi_fid_fk` (`ftradeid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1069582 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_question`;
CREATE TABLE `f_question` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `ftype` int(11) DEFAULT NULL,
  `fdesc` text,
  `ftelephone` varchar(32) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `faid` int(11) DEFAULT NULL,
  `fname` varchar(32) DEFAULT NULL,
  `fanswer` text,
  `version` int(11) DEFAULT NULL,
  `fcid` int(11) DEFAULT NULL,
  `fisanswer` int(1) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `fuid` (`fuid`) USING BTREE,
  KEY `faid` (`faid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_rebate_log`;
CREATE TABLE `f_rebate_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL COMMENT '用户id',
  `type` int(1) DEFAULT NULL COMMENT '1手续费返还  2下级返佣',
  `cuid` int(10) DEFAULT NULL COMMENT '下级ID',
  `num` decimal(24,8) DEFAULT NULL COMMENT '返佣数量',
  `status` int(1) DEFAULT NULL COMMENT '1未结算 2已结算',
  `inputtime` datetime DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6201 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='用户返佣记录表';

DROP TABLE IF EXISTS  `f_reward_code`;
CREATE TABLE `f_reward_code` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fcode` varchar(32) DEFAULT NULL,
  `famount` decimal(24,4) DEFAULT NULL,
  `fstate` tinyint(1) DEFAULT '0' COMMENT '0涓烘縺娲?1宸叉縺娲',
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fbatch` int(11) DEFAULT NULL,
  `fislimituser` tinyint(1) DEFAULT NULL,
  `fislimituse` tinyint(1) DEFAULT NULL,
  `fusenum` int(11) DEFAULT NULL,
  `fusedate` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `fcode` (`fcode`) USING BTREE,
  KEY `fuid` (`fuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_role`;
CREATE TABLE `f_role` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fdescription` varchar(256) DEFAULT NULL,
  `fname` varchar(64) NOT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `unique_name` (`fname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_role_security`;
CREATE TABLE `f_role_security` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fsecurityid` int(11) DEFAULT NULL,
  `froleid` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `FK9B6EA402BB04F1F` (`fsecurityid`) USING BTREE,
  KEY `FK9B6EA403FFD717F` (`froleid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13938 DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;

