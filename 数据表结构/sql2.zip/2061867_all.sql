﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `f_security`;
CREATE TABLE `f_security` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fdescription` varchar(255) DEFAULT NULL,
  `fname` varchar(32) DEFAULT NULL,
  `fpriority` int(11) DEFAULT NULL,
  `fparentid` int(20) DEFAULT NULL,
  `furl` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=330 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_system_bankinfo_recharge`;
CREATE TABLE `f_system_bankinfo_recharge` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fbankname` varchar(128) DEFAULT NULL,
  `fownername` varchar(128) DEFAULT NULL,
  `fbankaddress` varchar(256) DEFAULT NULL,
  `fbanknumber` varchar(128) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fbanktype` int(11) NOT NULL,
  `fsortid` int(11) DEFAULT NULL,
  `fusetype` int(11) DEFAULT '0',
  `fbankcode` varchar(32) DEFAULT '',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统充值银行卡信息，包括银行、卡号、姓名,  状态：（是否停用银行卡）';

DROP TABLE IF EXISTS  `f_system_args`;
CREATE TABLE `f_system_args` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fkey` varchar(100) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fvalue` varchar(2048) DEFAULT NULL,
  `fdescription` varchar(1024) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `furl` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `fKey_seq` (`fkey`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COMMENT='绯荤粺鍙傛暟';

DROP TABLE IF EXISTS  `f_system_bankinfo_withdraw`;
CREATE TABLE `f_system_bankinfo_withdraw` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcnname` varchar(64) DEFAULT NULL,
  `ftwname` varchar(64) DEFAULT NULL,
  `fenname` varchar(64) DEFAULT NULL,
  `flogo` varchar(128) DEFAULT NULL,
  `ftype` int(1) DEFAULT NULL COMMENT '0,只能充值，1充值提现',
  `fsort` int(11) DEFAULT NULL,
  `bank_code` varchar(32) DEFAULT NULL,
  `fstate` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_system_lan`;
CREATE TABLE `f_system_lan` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fsortid` int(11) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `fname` varchar(64) DEFAULT NULL,
  `ftype` varchar(32) DEFAULT NULL,
  `fshortname` varchar(32) DEFAULT NULL,
  `fpackagename` varchar(128) DEFAULT NULL,
  `fdescription` varchar(128) DEFAULT NULL,
  `fisrealname` tinyint(11) DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_user`;
CREATE TABLE `f_user` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fshowid` int(11) DEFAULT NULL,
  `floginname` varchar(32) DEFAULT NULL,
  `fnickname` varchar(32) DEFAULT NULL,
  `favatar` text COMMENT 'ͷ?',
  `floginpassword` varchar(32) DEFAULT NULL,
  `ftradepassword` varchar(32) DEFAULT NULL,
  `ftelephone` varchar(32) DEFAULT NULL,
  `femail` varchar(128) DEFAULT NULL,
  `frealname` varchar(32) DEFAULT NULL,
  `fidentityno` varchar(128) DEFAULT NULL,
  `fidentitytype` int(11) DEFAULT NULL,
  `fgoogleauthenticator` varchar(128) DEFAULT NULL,
  `fgoogleurl` varchar(128) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `fhasrealvalidate` tinyint(1) DEFAULT NULL,
  `fhasrealvalidatetime` datetime DEFAULT NULL,
  `fistelephonebind` tinyint(1) DEFAULT NULL,
  `fismailbind` tinyint(1) DEFAULT NULL,
  `fgooglebind` tinyint(1) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `ftradepwdtime` datetime DEFAULT NULL,
  `fareacode` varchar(32) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fintrouid` int(11) DEFAULT NULL,
  `finvalidateintrocount` int(11) DEFAULT NULL,
  `fiscny` tinyint(1) DEFAULT NULL COMMENT '?????提现',
  `fiscoin` tinyint(1) DEFAULT NULL COMMENT '?????提币',
  `fbirth` date DEFAULT NULL,
  `flastlogintime` datetime DEFAULT NULL,
  `fregistertime` datetime DEFAULT NULL,
  `fleverlock` int(11) DEFAULT '0',
  `fqqopenid` varchar(128) DEFAULT NULL,
  `funionid` varchar(128) DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  `flastip` bigint(20) DEFAULT NULL,
  `folduid` int(11) DEFAULT NULL,
  `fplatform` int(11) DEFAULT '1',
  `is_video` tinyint(1) DEFAULT NULL,
  `frytoken` varchar(255) DEFAULT NULL COMMENT '????token',
  `video_time` datetime DEFAULT NULL,
  `trade_status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `flogin_name` (`floginname`) USING BTREE,
  KEY `fIntroUser_id_fk` (`fintrouid`) USING BTREE,
  KEY `fId` (`fid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=43442 DEFAULT CHARSET=utf8 COMMENT='用户信息';

DROP TABLE IF EXISTS  `f_user_bankinfo`;
CREATE TABLE `f_user_bankinfo` (
  `fId` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fname` varchar(128) DEFAULT NULL,
  `fbanknumber` varchar(128) DEFAULT NULL,
  `fbanktype` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `init` tinyint(1) DEFAULT NULL,
  `faddress` varchar(200) DEFAULT NULL,
  `frealname` varchar(64) DEFAULT NULL,
  `fprov` varchar(64) DEFAULT NULL,
  `fcity` varchar(64) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL COMMENT '0閾惰?鍗?鏀?粯瀹',
  `fdist` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fId`),
  KEY `FK_Relationship_19` (`fuid`) USING BTREE,
  KEY `fBankType` (`fbanktype`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='閾惰?鍗′俊鎭?紝鐢ㄤ簬鎻愮幇.鍏呭?鍦板潃姣忎竴娆￠兘闇??鎵嬪伐濉?啓锛';

DROP TABLE IF EXISTS  `f_user_finances`;
CREATE TABLE `f_user_finances` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fcoinid` int(11) DEFAULT NULL,
  `fname` varchar(64) DEFAULT NULL,
  `frate` decimal(24,10) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL,
  `fplanamount` decimal(24,10) DEFAULT NULL,
  `fstate` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `f_user_finances_fuid` (`fuid`) USING BTREE,
  KEY `f_user_finances_fcoinid` (`fcoinid`) USING BTREE,
  KEY `f_user_finances_fstate` (`fstate`) USING BTREE,
  KEY `f_user_finances_fupdatetime` (`fupdatetime`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_user_identity`;
CREATE TABLE `f_user_identity` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fcountry` varchar(255) DEFAULT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `fcode` varchar(255) DEFAULT NULL,
  `ftype` int(1) DEFAULT NULL,
  `fstatus` int(1) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `idCardZmImgURL` varchar(255) DEFAULT NULL,
  `idCardFmImgURL` varchar(255) DEFAULT NULL,
  `idCardScImgURL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `f_user_identity_fuid` (`fuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33937 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_user_info`;
CREATE TABLE `f_user_info` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fname` varchar(32) DEFAULT NULL,
  `fphone` varchar(32) DEFAULT NULL,
  `fzipcode` varchar(32) DEFAULT NULL,
  `fprov` varchar(32) DEFAULT NULL,
  `fcity` varchar(32) DEFAULT NULL,
  `fdist` varchar(32) DEFAULT NULL,
  `faddress` varchar(128) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_user_priceclock`;
CREATE TABLE `f_user_priceclock` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `ftradeid` int(11) DEFAULT NULL,
  `fmaxprice` decimal(24,10) DEFAULT NULL,
  `fminprice` decimal(24,10) DEFAULT NULL,
  `fisopen` tinyint(1) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `f_user_priceclock_fuid` (`fuid`) USING BTREE,
  KEY `f_user_priceclock_fisopen` (`fisopen`) USING BTREE,
  KEY `f_user_priceclock_fmaxprice` (`fmaxprice`) USING BTREE,
  KEY `f_user_priceclock_fminprice` (`fminprice`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_user_push`;
CREATE TABLE `f_user_push` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fpushuid` int(11) DEFAULT NULL,
  `fcoinid` int(11) DEFAULT NULL,
  `fprice` decimal(24,10) DEFAULT NULL,
  `fcount` decimal(24,10) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL,
  `fstate` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fremark` varchar(512) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `f_user_push_fpushuid` (`fpushuid`) USING BTREE,
  KEY `f_user_push_fuid` (`fuid`) USING BTREE,
  KEY `f_user_push_fstate` (`fstate`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_user_score`;
CREATE TABLE `f_user_score` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fscore` decimal(24,10) DEFAULT NULL,
  `flevel` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `ftradingqty` int(11) DEFAULT NULL,
  `fleveltime` datetime DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `f_user_score_fuid` (`fuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=39057 DEFAULT CHARSET=gb2312;

DROP TABLE IF EXISTS  `f_user_virtual_address`;
CREATE TABLE `f_user_virtual_address` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `fadderess` varchar(180) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `fAdderess_seq__` (`fadderess`) USING BTREE,
  KEY `FK_Relationship_22` (`fcoinid`) USING BTREE,
  KEY `fuid_fks` (`fuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1883 DEFAULT CHARSET=utf8 COMMENT='铏氭嫙閽卞寘鍦板潃锛岀敤浜庡?鍏ュ拰瀵煎嚭铏氭嫙甯';

DROP TABLE IF EXISTS  `f_user_virtual_address_withdraw`;
CREATE TABLE `f_user_virtual_address_withdraw` (
  `fId` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `fadderess` varchar(128) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `init` tinyint(1) DEFAULT NULL,
  `fremark` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`fId`),
  KEY `FK_Relationship_22` (`fcoinid`) USING BTREE,
  KEY `fuid_fk` (`fuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COMMENT='铏氭嫙閽卞寘鍦板潃锛岀敤浜庡?鍏ュ拰瀵煎嚭铏氭嫙甯';

DROP TABLE IF EXISTS  `f_virtual_capital_operation`;
CREATE TABLE `f_virtual_capital_operation` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) DEFAULT NULL,
  `fcoinid` int(11) DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL,
  `ffees` decimal(24,10) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `tx_time` datetime DEFAULT NULL,
  `fwithdrawaddress` varchar(128) DEFAULT NULL,
  `frechargeaddress` varchar(128) DEFAULT NULL,
  `funiquenumber` varchar(180) DEFAULT NULL,
  `fconfirmations` int(11) DEFAULT NULL,
  `fhasowner` tinyint(1) DEFAULT NULL,
  `fblocknumber` int(11) DEFAULT '0',
  `fbtcfees` decimal(24,10) DEFAULT '0.0000000000',
  `fadminid` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  `fsource` int(11) DEFAULT '1',
  `fnonce` int(11) DEFAULT '0',
  `fplatform` int(11) DEFAULT NULL,
  `memo` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `ftradeUniqueNumber` (`funiquenumber`) USING BTREE,
  KEY `FK_Relationship_15` (`fuid`) USING BTREE,
  KEY `FK_Relationship_13` (`fcoinid`) USING BTREE,
  KEY `int_add_fk` (`frechargeaddress`) USING BTREE,
  KEY `out_add_fk` (`fwithdrawaddress`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=utf8 COMMENT='铏氭嫙甯佽祫閲戞祦鍚';

DROP TABLE IF EXISTS  `f_virtual_finances`;
CREATE TABLE `f_virtual_finances` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL,
  `fname` varchar(64) DEFAULT NULL,
  `fdays` int(11) DEFAULT NULL,
  `frate` decimal(24,10) DEFAULT NULL,
  `fstate` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `f_virtual_finances_fcoinid` (`fcoinid`) USING BTREE,
  KEY `f_virtual_finances_fstate` (`fstate`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `f_wallet_capital_operation`;
CREATE TABLE `f_wallet_capital_operation` (
  `fId` int(11) NOT NULL AUTO_INCREMENT,
  `fcoinid` int(11) DEFAULT NULL COMMENT '币种ID',
  `fsysbankid` int(11) DEFAULT NULL,
  `fuid` int(11) DEFAULT NULL,
  `fcreatetime` datetime DEFAULT NULL,
  `famount` decimal(24,10) DEFAULT NULL,
  `finouttype` int(11) DEFAULT NULL,
  `ftype` int(11) DEFAULT NULL,
  `fstatus` int(11) DEFAULT NULL,
  `fremittancetype` int(11) DEFAULT NULL,
  `fremark` varchar(256) DEFAULT NULL,
  `fbank` varchar(256) DEFAULT NULL,
  `faccount` varchar(256) DEFAULT NULL,
  `fpayee` varchar(256) DEFAULT NULL,
  `fbank_code` varchar(32) DEFAULT NULL COMMENT '银行编号',
  `fphone` varchar(256) DEFAULT NULL,
  `fupdatetime` datetime DEFAULT NULL,
  `fadminid` int(9) DEFAULT NULL,
  `ffees` decimal(24,10) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fischarge` tinyint(4) DEFAULT NULL,
  `faddress` varchar(128) DEFAULT NULL,
  `fagentid` int(11) DEFAULT '0',
  `fsource` int(11) DEFAULT '1',
  `fplatform` int(11) unsigned DEFAULT NULL,
  `fserialno` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fId`),
  KEY `FK_Relationship_14` (`fuid`) USING BTREE,
  KEY `FK_Relationship_24` (`fsysbankid`) USING BTREE,
  KEY `fAuditee_id` (`fadminid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='璧勯噾璁板綍';

DROP TABLE IF EXISTS  `report_login`;
CREATE TABLE `report_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` int(1) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `hour_index` int(11) DEFAULT NULL,
  `gmt_begin` datetime DEFAULT NULL,
  `gmt_end` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `report_capital`;
CREATE TABLE `report_capital` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coin_id` int(11) DEFAULT NULL,
  `type` int(1) DEFAULT NULL COMMENT '充提类型',
  `amount` decimal(24,10) DEFAULT NULL,
  `fee` decimal(24,10) DEFAULT NULL,
  `hour_index` int(2) DEFAULT NULL,
  `gmt_begin` datetime DEFAULT NULL,
  `gmt_end` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `finance_record`;
CREATE TABLE `finance_record` (
  `fid` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `relation_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联id',
  `relation_coin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联的币种id',
  `relation_coin_name` varchar(225) NOT NULL DEFAULT '' COMMENT '关联的币种名称',
  `amount` decimal(24,10) NOT NULL DEFAULT '0.0000000000' COMMENT '金额',
  `operation` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '记录操作',
  `status` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '记录状态',
  `tx_id` varchar(255) NOT NULL DEFAULT '' COMMENT '交易id',
  `recharge_address` varchar(255) NOT NULL DEFAULT '' COMMENT '充值地址',
  `withdraw_address` varchar(255) NOT NULL DEFAULT '' COMMENT '提现地址',
  `memo` varchar(255) NOT NULL DEFAULT '' COMMENT '交易标签',
  `fee` decimal(24,10) NOT NULL DEFAULT '0.0000000000' COMMENT '手续费',
  `wallet_operation_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '钱包处理时间',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`fid`),
  KEY `key_uid` (`uid`),
  KEY `key_relation_id` (`relation_id`),
  KEY `key_operation` (`operation`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `report_trade`;
CREATE TABLE `report_trade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trade_id` int(11) DEFAULT NULL,
  `buy_coin_id` int(11) DEFAULT NULL,
  `sell_coin_id` int(11) DEFAULT NULL,
  `trade_amount` decimal(24,10) DEFAULT NULL,
  `trade_count` decimal(24,10) DEFAULT NULL,
  `trade_fee` decimal(24,10) DEFAULT NULL,
  `type` int(1) DEFAULT NULL COMMENT '买卖类型',
  `hour_index` int(2) DEFAULT NULL,
  `gmt_begin` datetime DEFAULT NULL,
  `gmt_end` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=387 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `system_activity`;
CREATE TABLE `system_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `archive_status` int(2) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `report_user`;
CREATE TABLE `report_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` int(1) DEFAULT NULL,
  `register` int(11) DEFAULT NULL,
  `total_login` int(11) DEFAULT NULL,
  `yester_login` int(11) DEFAULT NULL,
  `three_login` int(11) DEFAULT NULL,
  `week_login` int(11) DEFAULT NULL,
  `month_login` int(11) DEFAULT NULL,
  `gmt_begin` datetime DEFAULT NULL,
  `gmt_end` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `system_coin_setting`;
CREATE TABLE `system_coin_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coin_id` int(11) DEFAULT NULL,
  `level_vip` int(11) DEFAULT NULL,
  `withdraw_max` decimal(24,10) DEFAULT NULL,
  `withdraw_min` decimal(24,10) DEFAULT NULL,
  `withdraw_fee` decimal(24,10) DEFAULT NULL,
  `withdraw_times` int(11) DEFAULT NULL,
  `withdraw_single_limit` decimal(24,10) DEFAULT NULL,
  `withdraw_day_limit` decimal(24,10) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_coin_setting_coin_id` (`coin_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=gb2312 COMMENT='交易手续费';

DROP TABLE IF EXISTS  `system_coin_info`;
CREATE TABLE `system_coin_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coin_id` int(11) DEFAULT NULL,
  `name_zh` varchar(64) DEFAULT NULL,
  `name_en` varchar(64) DEFAULT NULL,
  `name_short` varchar(64) DEFAULT NULL,
  `total` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `circulation` varchar(50) DEFAULT NULL,
  `algorithm` varchar(64) DEFAULT NULL,
  `block_velocity` varchar(64) DEFAULT NULL,
  `block_size` varchar(64) DEFAULT NULL,
  `ico` varchar(64) DEFAULT NULL,
  `ico_platform` varchar(64) DEFAULT NULL,
  `link_website` varchar(128) DEFAULT NULL,
  `link_wallet` varchar(128) DEFAULT NULL,
  `link_block` varchar(128) DEFAULT NULL,
  `link_whitepaper` varchar(128) DEFAULT NULL,
  `official_qq` varchar(128) DEFAULT NULL,
  `official_wechat` varchar(128) DEFAULT NULL,
  `official_phone` varchar(128) DEFAULT NULL,
  `info` varchar(5120) DEFAULT NULL,
  `short_info` varchar(128) DEFAULT NULL,
  `lan_name` varchar(64) DEFAULT NULL,
  `gmt_release` varchar(64) DEFAULT '',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `system_coin_type`;
CREATE TABLE `system_coin_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sort_id` int(11) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `short_name` varchar(16) DEFAULT NULL,
  `symbol` varchar(3) DEFAULT NULL,
  `type` int(11) unsigned DEFAULT NULL,
  `coin_type` int(11) unsigned DEFAULT NULL,
  `status` int(11) unsigned DEFAULT NULL,
  `platform_id` int(11) DEFAULT NULL,
  `is_withdraw` tinyint(1) unsigned DEFAULT NULL,
  `is_recharge` tinyint(1) unsigned DEFAULT NULL,
  `risk_num` decimal(24,4) DEFAULT NULL,
  `is_push` tinyint(1) unsigned DEFAULT '0',
  `is_finances` tinyint(1) unsigned DEFAULT '0',
  `ip` varchar(32) DEFAULT NULL,
  `port` varchar(16) DEFAULT NULL,
  `access_key` varchar(64) DEFAULT NULL,
  `secrt_key` varchar(64) DEFAULT NULL,
  `asset_id` bigint(20) DEFAULT NULL,
  `network_fee` decimal(24,10) DEFAULT NULL,
  `confirmations` int(11) unsigned DEFAULT NULL,
  `eth_account` varchar(128) DEFAULT NULL,
  `web_logo` varchar(256) DEFAULT NULL,
  `app_logo` varchar(256) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) unsigned DEFAULT NULL,
  `contract_account` varchar(255) DEFAULT NULL,
  `contract_wei` int(11) unsigned DEFAULT NULL,
  `explorer_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `system_trade_type`;
CREATE TABLE `system_trade_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sort_id` int(11) unsigned DEFAULT NULL,
  `type` int(11) unsigned DEFAULT NULL,
  `status` int(11) unsigned DEFAULT NULL,
  `buy_coin_id` int(11) unsigned DEFAULT NULL,
  `sell_coin_id` int(11) unsigned DEFAULT NULL,
  `is_share` tinyint(1) unsigned DEFAULT NULL,
  `is_stop` tinyint(1) unsigned DEFAULT '1',
  `open_time` time DEFAULT NULL,
  `stop_time` time DEFAULT NULL,
  `buy_fee` decimal(24,10) DEFAULT NULL,
  `sell_fee` decimal(24,10) DEFAULT NULL,
  `remote_id` int(11) unsigned DEFAULT NULL,
  `price_wave` decimal(24,4) DEFAULT NULL,
  `price_range` decimal(24,4) DEFAULT NULL,
  `min_count` decimal(24,4) DEFAULT NULL,
  `max_count` decimal(24,4) DEFAULT NULL,
  `min_price` decimal(24,4) DEFAULT '0.0000',
  `max_price` decimal(24,4) DEFAULT '0.0000',
  `amount_offset` varchar(255) DEFAULT NULL,
  `price_offset` varchar(255) DEFAULT NULL,
  `digit` varchar(255) DEFAULT NULL,
  `open_price` decimal(24,10) DEFAULT NULL,
  `agent_id` int(10) unsigned DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) unsigned DEFAULT NULL,
  `tradeBlock` tinyint(32) DEFAULT '0' COMMENT '交易板块',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_coin_wallet`;
CREATE TABLE `user_coin_wallet` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(15) DEFAULT NULL,
  `coin_id` int(11) DEFAULT NULL,
  `total` decimal(24,10) DEFAULT NULL,
  `frozen` decimal(24,10) DEFAULT NULL,
  `borrow` decimal(24,10) DEFAULT NULL,
  `ico` decimal(24,10) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fuservirtualwallet_fcoinid` (`coin_id`) USING BTREE,
  KEY `fuservirtualwallet_fuid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=522578 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `validate_account`;
CREATE TABLE `validate_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  `access_key` varchar(255) DEFAULT NULL,
  `secret_key` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `validate_email`;
CREATE TABLE `validate_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `platform` int(1) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `code` varchar(10) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `gmt_send` datetime DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `version` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46970 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `validate_platform`;
CREATE TABLE `validate_platform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `sign` varchar(255) DEFAULT NULL,
  `sms_id` int(11) DEFAULT NULL,
  `voice_sms_id` int(11) DEFAULT NULL,
  `international_sms_id` int(11) DEFAULT NULL,
  `email_id` int(11) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `validate_sms`;
CREATE TABLE `validate_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `content` text,
  `send_type` int(1) DEFAULT NULL,
  `platform` int(11) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_send` datetime DEFAULT NULL,
  `version` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28893 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `validate_statistics`;
CREATE TABLE `validate_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform` int(11) DEFAULT NULL,
  `send_type` int(11) DEFAULT NULL,
  `times` int(11) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20924 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `validate_template`;
CREATE TABLE `validate_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `send_type` int(2) DEFAULT NULL,
  `business_type` varchar(255) DEFAULT NULL,
  `platform` int(1) DEFAULT NULL,
  `language` int(1) DEFAULT NULL,
  `template` text,
  `params` varchar(128) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `version` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;

