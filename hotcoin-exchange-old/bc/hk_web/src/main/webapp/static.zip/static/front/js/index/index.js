var login = {
    lastPriceList : {},
    login: function (ele) {
        var url = "/login.html";
        var uName = $("#indexLoginName").val();
        var pWord = $("#indexLoginPwd").val();
        var longLogin = 0;
        if (util.checkEmail(uName)) {
            longLogin = 1;
        }
        var des = util.isPassword(pWord);
        if (des != "") {
            util.layerAlert("", des);
            return;
        }
        var param = {
            loginName: uName,
            password: pWord,
            type: longLogin
        };
        var callback = function (data) {
            if (data.code == 200) {
                if ($("#forwardUrl").length > 0 && $("#forwardUrl").val() != "") {
                    var forward = $("#forwardUrl").val();
                    forward = decodeURI(forward);
                    window.location.href = forward;
                } else {
                    var whref = document.location.href;
                    if (whref.indexOf("#") != -1) {
                        whref = whref.substring(0, whref.indexOf("#"));
                    }
                    window.location.href = whref;
                }
            } else {
                util.layerAlert("", data.msg, 2);
                $("#indexLoginPwd").val("");
            }
        }
        ele = ele || $("#loginbtn")[0];
        util.network({btn: ele, url: url, param: param, success: callback, enter: true});
    },
    newsHover: function (ele) {
        $(".news-items").removeClass("active");
        $(".news-items").stop().animate({width: "345px"}, 50);
        $(ele).stop().animate({width: "450px"}, 50);
        $(ele).addClass("active");
    },
    aotoMarket: function () {
        var green = "#72c02c";
        var red = "#e74c3c";
        var url = "/real/indexmarket.html";
        var callback = function (result) {
            if (result.code != 200) {
                return;
            }

            var marketObject = {};
            $.each(result.data, function (index, data) {
                var market = "";
                var color = red;
                /*if(typeof(login.lastPriceList[data.tradeId]) !== "undefined" && login.lastPriceList[data.tradeId] < data.price){
                    color = green;
                }*/
                if(Number(data.rose)>=0){
                    color = green;
                }

                login.lastPriceList[data.tradeId] = data.rose;
                if (index % 2 == 1) {
                    market += "<article class='child-market'>";
                } else {
                    market += "<article class='child-market market-color'>";
                }
                market += "<div class=\"container market-item\">";
                market +=
                    "<span class=\"coin-name\"><img class='coin-logo' src='" + data.image + "' />" + data.sellname
                    + "</span>";
                market +=
                    "<span class=\"coin-price\">" + data.buysymbol + " " + util.numFormat(data.price, data.cnyDigit)
                    + "</span>";
                market +=
                    "<span class=\"coin-buy\">" + data.buysymbol + " " + util.numFormat(data.buy, data.cnyDigit)
                    + "</span>";
                market +=
                    "<span class=\"coin-sell\">" + data.buysymbol + " " + util.numFormat(data.sell, data.cnyDigit)
                    + "</span>";
                market +=
                    "<span class=\"coin-vol\">" + util.numFormat(data.total, data.coinDigit) + " " + data.sellsymbol
                    + "</span>";
                market += "<span class=\"coin-chg\" style='color:"+color+"'>" + data.rose + "%</span>";
                market += "<a href='/trade/cny_coin.html?tradeId="+data.treadId+"&type="+data.type+"'>"+util.getLan("index.go.trade")+"</a>";
                market += "</div>";
                market += "</article>";
                marketObject[data.type] =
                    (typeof marketObject[data.type] === "undefined" ? "" : marketObject[data.type]) + market;
            });
            $(".child-market", ".market").remove();
            for (var type in marketObject) {
                $("#marketType" + type).append(marketObject[type]);
            }
        };
        util.network({url: url, param: {}, success: callback});
        setTimeout(login.aotoMarket, 5000);
    },
    switchMarket: function () {
        $(".trade-tab").on("click", function () {
            var $that = $(this);
            var dataClass = $that.data().market;
            $(".trade-tab").removeClass("active");
            $that.addClass("active");
            $(".market-con").hide();
            $("#" + dataClass).show();
        })
    }
};
$(function () {
    $("#indexLoginPwd").on("focus", function () {
        util.callbackEnter(login.login);
    });
    $("#loginbtn").on("click", function () {
        login.login(this);
    });
    $(".news-items").mouseover(function (ele) {
        login.newsHover(this);
    });
    login.aotoMarket();
    login.switchMarket();
});
