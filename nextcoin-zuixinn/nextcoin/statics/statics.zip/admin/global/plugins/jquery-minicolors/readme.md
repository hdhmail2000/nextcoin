# jQuery MiniColors: A tiny color picker built on jQuery

_Copyright Cory LaViska for A Beautiful Site, LLC. (http://www.abeautifulsite.net/)_

_Licensed under the MIT license_

## Demo & Documentation

http://labs.abeautifulsite.net/jquery-minicolors/